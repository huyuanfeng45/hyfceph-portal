#!/usr/bin/env node

import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { promisify } from 'node:util';
import { parseArgs } from 'node:util';
import { fileURLToPath } from 'node:url';

const execFileAsync = promisify(execFile);
const PAGE_WIDTH = 1240;
const PAGE_HEIGHT = 1754;
const MARGIN_X = 72;
const MARGIN_Y = 72;
const CONTENT_WIDTH = PAGE_WIDTH - MARGIN_X * 2;
const MAX_PAGE_IMAGE_WIDTH = CONTENT_WIDTH;
const SECTION_GAP = 26;
const CHROME_CANDIDATES = [
  process.env.HYFCEPH_CHROME_PATH,
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  'google-chrome',
  'chrome',
  'chromium',
  'chromium-browser',
].filter(Boolean);

function escapeXml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;');
}

function ensureArray(value) {
  return Array.isArray(value) ? value : [];
}

function round1(value) {
  return Math.round(Number(value) * 10) / 10;
}

function toTitleCase(value) {
  return String(value || '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function formatDateTime(value) {
  if (!value) {
    return '-';
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return String(value);
  }
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatDateOnly(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return String(value);
  }
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

function formatFrameworkStatus(value) {
  if (value === 'supported') return '支持';
  if (value === 'partial') return '部分支持';
  if (value === 'unsupported') return '暂不支持';
  return String(value || '-');
}

function estimateCharUnits(char) {
  if (/[\u4e00-\u9fff]/u.test(char)) return 1;
  if (/\s/u.test(char)) return 0.35;
  if (/[A-Z0-9]/.test(char)) return 0.68;
  if (/[a-z]/.test(char)) return 0.58;
  return 0.62;
}

function wrapText(text, maxUnits) {
  const source = String(text || '').replace(/\r/g, '').split('\n');
  const lines = [];
  for (const paragraph of source) {
    const trimmed = paragraph.trim();
    if (!trimmed) {
      lines.push('');
      continue;
    }
    let current = '';
    let currentUnits = 0;
    for (const char of trimmed) {
      const units = estimateCharUnits(char);
      if (current && currentUnits + units > maxUnits) {
        lines.push(current);
        current = char;
        currentUnits = units;
      } else {
        current += char;
        currentUnits += units;
      }
    }
    if (current) {
      lines.push(current);
    }
  }
  return lines.length ? lines : [''];
}

function defaultPdfPath(inputPath) {
  const parsed = path.parse(inputPath);
  return path.join(parsed.dir, `${parsed.name}.report.pdf`);
}

function toneColor(tone) {
  if (tone === 'success') return '#13805f';
  if (tone === 'danger') return '#bd3f2f';
  if (tone === 'warn') return '#8f5c16';
  return '#5c4bc4';
}

function safeMetricValue(metric) {
  if (!metric) return '-';
  return metric.valueText || (Number.isFinite(metric.value) ? String(metric.value) : '-');
}

function normalizeFrameworkEntries(frameworkReports, preferredOrder = []) {
  const reports = frameworkReports && typeof frameworkReports === 'object' ? frameworkReports : {};
  const byCode = Object.values(reports);
  const ordered = [];
  const used = new Set();
  for (const name of preferredOrder) {
    const found = byCode.find((report) => report?.label === name || report?.code === name);
    if (found && !used.has(found.code)) {
      ordered.push(found);
      used.add(found.code);
    }
  }
  for (const report of byCode) {
    if (report?.code && !used.has(report.code)) {
      ordered.push(report);
      used.add(report.code);
    }
  }
  return ordered;
}

async function canExecute(command) {
  try {
    await execFileAsync(command, ['--version']);
    return true;
  } catch {
    return false;
  }
}

async function findChromeBinary() {
  for (const candidate of CHROME_CANDIDATES) {
    if (await canExecute(candidate)) {
      return candidate;
    }
  }
  return null;
}

function htmlText(value) {
  return escapeXml(value).replace(/\n/g, '<br />');
}

function toneLabel(tone, status) {
  if (status && status !== 'supported') return '未算出';
  if (tone === 'success') return '在范围内';
  if (tone === 'danger') return '偏离较大';
  if (tone === 'warn') return '轻度偏离';
  return '已计算';
}

function toneClass(tone, status) {
  if (status && status !== 'supported') return 'tone-muted';
  if (tone === 'success') return 'tone-success';
  if (tone === 'danger') return 'tone-danger';
  if (tone === 'warn') return 'tone-warn';
  return 'tone-default';
}

function rowToneClass(tone, status) {
  if (status && status !== 'supported') return 'row-muted';
  if (tone === 'success') return 'row-success';
  if (tone === 'danger') return 'row-danger';
  if (tone === 'warn') return 'row-warn';
  return '';
}

function chineseSectionNumber(index) {
  const map = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'];
  return map[index - 1] || String(index);
}

function formatDeltaValue(baseItem, compareItem) {
  if (!baseItem || !compareItem || !Number.isFinite(baseItem.value) || !Number.isFinite(compareItem.value)) {
    return '-';
  }
  const delta = round1(compareItem.value - baseItem.value);
  const unit = compareItem.unit || baseItem.unit || '';
  if (unit === 'mm') return `${delta} mm`;
  if (unit === '%') return `${delta}%`;
  return `${delta}°`;
}

function buildMetricComparisonRows(baseMetrics, compareMetrics) {
  const baseMetricMap = new Map(ensureArray(baseMetrics).map((metric) => [metric.code, metric]));
  const compareMetricMap = new Map(ensureArray(compareMetrics).map((metric) => [metric.code, metric]));
  return Array.from(new Set([...baseMetricMap.keys(), ...compareMetricMap.keys()])).map((code) => ({
    code,
    base: baseMetricMap.get(code) || null,
    compare: compareMetricMap.get(code) || null,
  }));
}

function renderMetricCards(metrics) {
  return `
    <div class="metric-grid">
      ${ensureArray(metrics).map((metric) => `
        <article class="metric-card">
          <div class="metric-code">${htmlText(metric.code || '-')}</div>
          <div class="metric-value ${toneClass(metric.tone, metric.status)}">${htmlText(safeMetricValue(metric))}</div>
          <div class="metric-label">${htmlText(metric.label || metric.code || '')}</div>
          <div class="metric-reference">${htmlText(metric.reference || '')}</div>
        </article>
      `).join('')}
    </div>
  `;
}

function renderReportInfoBox({ generatedAt, patientName }) {
  return `
    <section class="info-box">
      <div class="info-grid">
        <div class="info-item"><strong>患者姓名：</strong>${htmlText(patientName || '未提供')}</div>
        <div class="info-item"><strong>检查日期：</strong>${htmlText(formatDateOnly(generatedAt))}</div>
        <div class="info-item info-item-wide"><strong>测量系统：</strong>HYFCeph 头影测量分析系统</div>
      </div>
    </section>
  `;
}

function renderSingleMetricsTable(metrics) {
  return `
    <table class="framework-table metrics-table">
      <thead>
        <tr>
          <th>指标</th>
          <th>测量值</th>
          <th>参考值</th>
          <th>临床意义</th>
        </tr>
      </thead>
      <tbody>
        ${ensureArray(metrics).map((metric) => `
          <tr class="${rowToneClass(metric.tone, metric.status)}">
            <td><span class="mono">${htmlText(metric.code || '-')}</span></td>
            <td class="${toneClass(metric.tone, metric.status)}">${htmlText(safeMetricValue(metric))}</td>
            <td>${htmlText(metric.reference || '-')}</td>
            <td>${htmlText(metric.label || '-')}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function renderOverlapMetricsTable(rows) {
  return `
    <table class="framework-table metrics-table">
      <thead>
        <tr>
          <th>指标</th>
          <th>治疗前</th>
          <th>治疗后</th>
          <th>变化</th>
          <th>参考值</th>
          <th>临床意义</th>
        </tr>
      </thead>
      <tbody>
        ${rows.map((row) => `
          <tr class="${rowToneClass(row.compare?.tone || row.base?.tone, row.compare?.status || row.base?.status)}">
            <td><span class="mono">${htmlText(row.code || '-')}</span></td>
            <td class="${toneClass(row.base?.tone, row.base?.status)}">${htmlText(safeMetricValue(row.base))}</td>
            <td class="${toneClass(row.compare?.tone, row.compare?.status)}">${htmlText(safeMetricValue(row.compare))}</td>
            <td>${htmlText(formatDeltaValue(row.base, row.compare))}</td>
            <td>${htmlText(row.compare?.reference || row.base?.reference || '-')}</td>
            <td>${htmlText(row.compare?.label || row.base?.label || '-')}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function renderKeyMetricComparisonTable(rows) {
  return `
    <table class="framework-table">
      <thead>
        <tr>
          <th>指标</th>
          <th>治疗前</th>
          <th>治疗后</th>
          <th>变化</th>
        </tr>
      </thead>
      <tbody>
        ${rows.map((row) => `
          <tr>
            <td><span class="mono">${htmlText(row.code || '-')}</span></td>
            <td class="${toneClass(row.base?.tone, row.base?.status)}">${htmlText(safeMetricValue(row.base))}</td>
            <td class="${toneClass(row.compare?.tone, row.compare?.status)}">${htmlText(safeMetricValue(row.compare))}</td>
            <td>${htmlText(formatDeltaValue(row.base, row.compare))}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function renderSingleFrameworkTable(framework) {
  return `
    <table class="framework-table">
      <thead>
        <tr>
          <th>项目</th>
          <th>数值</th>
          <th>参考</th>
          <th>状态</th>
        </tr>
      </thead>
      <tbody>
        ${ensureArray(framework.items).map((item) => {
          const valueText = item.status === 'supported'
            ? (item.valueText || (Number.isFinite(item.value) ? String(item.value) : '-'))
            : `暂不支持：${item.reason || '-'}`;
          return `
            <tr class="${rowToneClass(item.tone, item.status)}">
              <td>${htmlText(item.label || item.code || '-')}</td>
              <td class="${toneClass(item.tone, item.status)}">${htmlText(valueText)}</td>
              <td>${htmlText(item.reference || '-')}</td>
              <td>${htmlText(toneLabel(item.tone, item.status))}</td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  `;
}

function renderOverlapFrameworkTable(label, baseFramework, compareFramework) {
  const rows = buildOverlapComparisonRows(baseFramework, compareFramework);
  return `
    <table class="framework-table">
      <thead>
        <tr>
          <th>项目</th>
          <th>治疗前</th>
          <th>治疗后</th>
          <th>参考</th>
          <th>差值</th>
        </tr>
      </thead>
      <tbody>
        ${rows.map((row) => `
          <tr class="${rowToneClass(row.compare?.tone || row.base?.tone, row.compare?.status || row.base?.status)}">
            <td>${htmlText(row.base?.label || row.compare?.label || row.code || '-')}</td>
            <td class="${toneClass(row.base?.tone, row.base?.status)}">${htmlText(row.base?.status === 'supported' ? (row.base?.valueText || '-') : '未算出')}</td>
            <td class="${toneClass(row.compare?.tone, row.compare?.status)}">${htmlText(row.compare?.status === 'supported' ? (row.compare?.valueText || '-') : '未算出')}</td>
            <td>${htmlText(row.base?.reference || row.compare?.reference || '-')}</td>
            <td>${htmlText(formatDeltaValue(row.base, row.compare))}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function renderFrameworkNarrative(sectionIndex, framework, mode, compareFramework) {
  const sectionNo = chineseSectionNumber(sectionIndex);
  const intro = framework?.note
    || (mode === 'overlap'
      ? `本页展示 ${framework?.label || compareFramework?.label || '该分析法'} 在治疗前后两次测量中的原始项目对比。`
      : `本页展示 ${framework?.label || '该分析法'} 的完整原始项目与参考范围。`);

  const diagnosis = mode === 'overlap'
    ? `治疗前：${baseFrameworkSummary(framework)}；治疗后：${baseFrameworkSummary(compareFramework)}。`
    : `当前状态：${formatFrameworkStatus(framework?.status)}；已输出 ${ensureArray(framework?.items).length} 个项目。`;

  return `
    <div class="section-heading"><span class="bar"></span><h2>${sectionNo}、${htmlText((framework?.label || compareFramework?.label || '分析法') + (mode === 'overlap' ? '对比' : ''))}</h2></div>
    <div class="subsection">
      <h3>${sectionIndex}.1 分析说明</h3>
      <div class="note-box">${htmlText(intro)}</div>
    </div>
    <div class="subsection">
      <h3>${sectionIndex}.2 结果摘要</h3>
      <p class="body-copy">${htmlText(diagnosis)}</p>
    </div>
    <div class="subsection">
      <h3>${sectionIndex}.3 原始数据明细</h3>
    </div>
  `;
}

function baseFrameworkSummary(framework) {
  if (!framework) return '未提供';
  return `${formatFrameworkStatus(framework.status)}，共 ${ensureArray(framework.items).length} 项`;
}

function renderImageAppendixPage(title, imageDataUri, caption) {
  if (!imageDataUri) return '';
  return `
    <section class="page appendix-page">
      <div class="mini-header">
        <div class="mini-date">${htmlText(formatDateTime(new Date().toISOString()))}</div>
        <div class="mini-title">HYFCeph 影像附页</div>
      </div>
      <div class="main-title">${htmlText(title)}</div>
      <div class="main-divider"></div>
      <figure class="image-frame large-frame">
        <img src="${imageDataUri}" alt="${htmlText(caption)}" />
        <figcaption>${htmlText(caption)}</figcaption>
      </figure>
    </section>
  `;
}

async function buildHtmlReport(payload) {
  const mode = String(payload.mode || payload.analysis?.type || 'image').trim();
  const reportTitle = mode === 'overlap' ? 'HYFCeph 重叠对比报告' : 'HYFCeph 侧位片测量报告';
  const generatedAt = formatDateTime(new Date().toISOString());
  const imageDataUri = await imageToDataUri(payload.annotatedPngPath || payload.annotatedSvgPath);
  const frameworkChoices = payload.frameworkChoices || payload.analysis?.frameworkChoices || payload.summary?.frameworkChoices || [];
  const patientName = String(payload.patientName || '').trim();

  let bodySections = '';

  if (mode === 'overlap') {
    const metricRows = buildMetricComparisonRows(payload.analysis?.base?.metrics, payload.analysis?.compare?.metrics);
    const baseFrameworks = normalizeFrameworkEntries(payload.analysis?.base?.frameworkReports, frameworkChoices);
    const compareFrameworkMap = new Map(
      normalizeFrameworkEntries(payload.analysis?.compare?.frameworkReports, frameworkChoices).map((item) => [item.code, item]),
    );

    bodySections += `
      <section class="page report-page">
        <div class="mini-header">
          <div class="mini-date">${htmlText(generatedAt)}</div>
          <div class="mini-title">${htmlText(reportTitle)}</div>
        </div>
        <div class="main-title">${htmlText(reportTitle)}</div>
        ${patientName ? `<div class="main-subtitle">患者：${htmlText(patientName)}</div>` : ''}
        <div class="main-divider"></div>
        ${renderReportInfoBox({ generatedAt, patientName })}
        <div class="section-heading"><span class="bar"></span><h2>一、基础测量数据对比</h2></div>
        ${renderOverlapMetricsTable(metricRows)}
        <div class="subsection">
          <h3>2.1 治疗前结论</h3>
          <p class="body-copy">${htmlText(payload.analysis?.base?.riskLabel || payload.summary?.baseRiskLabel || '-')}</p>
        </div>
        <div class="subsection">
          <h3>2.2 治疗后结论</h3>
          <p class="body-copy">${htmlText(payload.analysis?.compare?.riskLabel || payload.summary?.compareRiskLabel || '-')}</p>
        </div>
        <div class="subsection">
          <h3>2.3 对齐方式</h3>
          <p class="body-copy">${htmlText(payload.alignMode || payload.summary?.alignLabel || '-')}</p>
        </div>
      </section>
    `;

    baseFrameworks.forEach((framework, index) => {
      const sectionIndex = index + 2;
      bodySections += `
        <section class="page report-page">
          <div class="mini-header">
            <div class="mini-date">${htmlText(generatedAt)}</div>
            <div class="mini-title">${htmlText(reportTitle)}</div>
          </div>
          ${renderFrameworkNarrative(sectionIndex, framework, 'overlap', compareFrameworkMap.get(framework.code))}
          ${renderOverlapFrameworkTable(framework.label, framework, compareFrameworkMap.get(framework.code))}
        </section>
      `;
    });

    bodySections += renderImageAppendixPage('治疗前后重叠图', imageDataUri, '治疗前后重叠图');
  } else {
    const singleMetrics = payload.metrics || payload.analysis?.metrics || [];
    const frameworks = normalizeFrameworkEntries(payload.analysis?.frameworkReports, frameworkChoices);

    bodySections += `
      <section class="page report-page">
        <div class="mini-header">
          <div class="mini-date">${htmlText(generatedAt)}</div>
          <div class="mini-title">${htmlText(reportTitle)}</div>
        </div>
        <div class="main-title">${htmlText(reportTitle)}</div>
        ${patientName ? `<div class="main-subtitle">患者：${htmlText(patientName)}</div>` : ''}
        <div class="main-divider"></div>
        ${renderReportInfoBox({ generatedAt, patientName })}
        <div class="section-heading"><span class="bar"></span><h2>一、基础测量数据总览</h2></div>
        ${renderSingleMetricsTable(singleMetrics)}
        <div class="subsection">
          <h3>2.1 诊断提示</h3>
          <div class="note-box">${htmlText(payload.analysis?.insight || payload.summary?.riskLabel || '本次服务端测量已完成。')}</div>
        </div>
        <div class="subsection">
          <h3>2.2 风险标签</h3>
          <p class="body-copy">${htmlText(payload.analysis?.riskLabel || '-')}</p>
        </div>
      </section>
    `;

    frameworks.forEach((framework, index) => {
      const sectionIndex = index + 2;
      bodySections += `
        <section class="page report-page">
          <div class="mini-header">
            <div class="mini-date">${htmlText(generatedAt)}</div>
            <div class="mini-title">${htmlText(reportTitle)}</div>
          </div>
          ${renderFrameworkNarrative(sectionIndex, framework, 'single')}
          ${renderSingleFrameworkTable(framework)}
        </section>
      `;
    });

    bodySections += renderImageAppendixPage('标注图附页', imageDataUri, '自动定点标注图');
  }

  return `<!doctype html>
  <html lang="zh-CN">
    <head>
      <meta charset="utf-8" />
      <title>${htmlText(reportTitle)}</title>
      <style>
        @page {
          size: A4;
          margin: 14mm;
        }
        * {
          box-sizing: border-box;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        html, body {
          margin: 0;
          padding: 0;
          font-family: "PingFang SC","Noto Sans SC","Helvetica Neue",Arial,sans-serif;
          color: #2c2c2c;
          background: #ffffff;
        }
        body {
          font-size: 12px;
          line-height: 1.6;
        }
        .page {
          break-after: page;
          min-height: 268mm;
        }
        .page:last-child {
          break-after: auto;
        }
        .report-page,
        .appendix-page {
          padding: 4mm 2mm 2mm;
        }
        .mini-header {
          position: relative;
          min-height: 18px;
          margin-bottom: 16px;
          color: #666;
          font-size: 10px;
        }
        .mini-date {
          position: absolute;
          left: 0;
          top: 0;
        }
        .mini-title {
          text-align: center;
        }
        .main-title {
          text-align: center;
          font-size: 24px;
          font-weight: 700;
          color: #333;
          margin: 12px 0 10px;
        }
        .main-subtitle {
          text-align: center;
          font-size: 13px;
          color: #5a6470;
          margin: -2px 0 10px;
        }
        .main-divider {
          height: 1.5px;
          background: #444;
          margin: 0 0 16px;
        }
        .info-box {
          border: 1px solid #d9e1eb;
          background: #fbfdff;
          border-radius: 4px;
          padding: 14px 18px;
          margin-bottom: 18px;
        }
        .info-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px 18px;
        }
        .info-item {
          color: #3e4957;
        }
        .info-item strong {
          color: #333;
          font-weight: 700;
        }
        .info-item-wide {
          grid-column: 1 / -1;
        }
        .section-heading {
          display: flex;
          align-items: center;
          gap: 10px;
          margin: 18px 0 12px;
        }
        .section-heading .bar {
          width: 4px;
          height: 24px;
          border-radius: 2px;
          background: #3a9df5;
        }
        .section-heading h2 {
          margin: 0;
          font-size: 16px;
          color: #314559;
          font-weight: 800;
        }
        .subsection {
          margin-top: 14px;
        }
        .subsection h3 {
          margin: 0 0 8px;
          font-size: 13px;
          color: #41566d;
          font-weight: 700;
        }
        .body-copy {
          margin: 0;
          color: #4b5867;
        }
        .note-box {
          border: 1px solid #dce6ef;
          background: #f9fbfd;
          border-radius: 4px;
          padding: 12px 14px;
          color: #465668;
        }
        .framework-table {
          width: 100%;
          border-collapse: collapse;
          border-spacing: 0;
          margin-top: 10px;
          border: 1px solid #dfe5eb;
        }
        .framework-table thead {
          display: table-header-group;
        }
        .framework-table tr {
          page-break-inside: avoid;
        }
        .framework-table th {
          background: #f7f7f7;
          color: #4c5b6d;
          font-size: 11px;
          font-weight: 700;
          text-align: center;
          padding: 8px 10px;
          border: 1px solid #dfe5eb;
        }
        .framework-table td {
          padding: 8px 10px;
          border: 1px solid #e3e8ee;
          vertical-align: top;
          color: #2f3c4b;
        }
        .metrics-table td,
        .metrics-table th {
          text-align: center;
        }
        .metrics-table td:last-child,
        .metrics-table th:last-child {
          text-align: left;
        }
        .mono {
          font-family: Menlo, Consolas, monospace;
          font-weight: 700;
        }
        .row-success {
          background: #f3fbf6;
        }
        .row-danger {
          background: #fff7f2;
        }
        .row-warn {
          background: #fff8dc;
        }
        .row-muted {
          background: #faf8fb;
        }
        .tone-success { color: #1f9d55; font-weight: 700; }
        .tone-danger { color: #e67e22; font-weight: 700; }
        .tone-warn { color: #2ecc71; font-weight: 700; }
        .tone-default { color: #5c4bc4; font-weight: 700; }
        .tone-muted { color: #8b6380; }
        .image-frame {
          margin: 18px 0 0;
          text-align: center;
        }
        .large-frame img {
          display: block;
          max-width: 100%;
          max-height: 225mm;
          object-fit: contain;
          margin: 0 auto;
        }
        .large-frame figcaption {
          margin-top: 10px;
          font-size: 11px;
          color: #687789;
        }
      </style>
    </head>
    <body>
      ${bodySections}
    </body>
  </html>`;
}

async function renderHtmlToPdfWithChrome(html, outputPath) {
  const chromeBinary = await findChromeBinary();
  if (!chromeBinary) {
    throw new Error('Chrome not found');
  }

  const tempDir = await fs.mkdtemp(path.join(process.cwd(), 'hyfceph-html-pdf-'));
  const htmlPath = path.join(tempDir, 'report.html');
  await fs.writeFile(htmlPath, html, 'utf8');

  const args = [
    '--headless=new',
    '--disable-gpu',
    '--allow-file-access-from-files',
    '--print-to-pdf-no-header',
    `--print-to-pdf=${outputPath}`,
    `file://${htmlPath}`,
  ];

  try {
    await execFileAsync(chromeBinary, args);
  } catch {
    const fallbackArgs = [
      '--headless',
      '--disable-gpu',
      '--allow-file-access-from-files',
      '--print-to-pdf-no-header',
      `--print-to-pdf=${outputPath}`,
      `file://${htmlPath}`,
    ];
    await execFileAsync(chromeBinary, fallbackArgs);
  }

  return path.resolve(outputPath);
}

function buildJpegPdf(pages) {
  const objects = [];
  const addObject = (value) => {
    objects.push(value);
    return objects.length;
  };

  const imageObjectIds = [];
  const contentObjectIds = [];
  const pageObjectIds = [];

  for (const page of pages) {
    const imageId = addObject(
      `<< /Type /XObject /Subtype /Image /Width ${page.imageWidth} /Height ${page.imageHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${page.jpegBuffer.length} >>\nstream\n${page.jpegBuffer.toString('binary')}\nendstream`,
    );
    imageObjectIds.push(imageId);

    const content = `q\n595 0 0 842 0 0 cm\n/Im0 Do\nQ`;
    const contentId = addObject(`<< /Length ${Buffer.byteLength(content, 'utf8')} >>\nstream\n${content}\nendstream`);
    contentObjectIds.push(contentId);
  }

  const pagesId = addObject('');
  const catalogId = addObject(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);

  for (let index = 0; index < pages.length; index += 1) {
    const pageId = addObject(
      `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 ${imageObjectIds[index]} 0 R >> >> /Contents ${contentObjectIds[index]} 0 R >>`,
    );
    pageObjectIds.push(pageId);
  }

  objects[pagesId - 1] = `<< /Type /Pages /Count ${pageObjectIds.length} /Kids [${pageObjectIds.map((id) => `${id} 0 R`).join(' ')}] >>`;

  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  for (let index = 0; index < objects.length; index += 1) {
    offsets.push(Buffer.byteLength(pdf, 'binary'));
    pdf += `${index + 1} 0 obj\n${objects[index]}\nendobj\n`;
  }
  const xrefOffset = Buffer.byteLength(pdf, 'binary');
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += '0000000000 65535 f \n';
  for (let index = 1; index < offsets.length; index += 1) {
    pdf += `${String(offsets[index]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  return Buffer.from(pdf, 'binary');
}

async function imageToDataUri(filePath) {
  if (!filePath) return null;
  const buffer = await fs.readFile(filePath);
  const ext = path.extname(filePath).toLowerCase();
  const mime = ext === '.svg'
    ? 'image/svg+xml'
    : ext === '.jpg' || ext === '.jpeg'
      ? 'image/jpeg'
      : 'image/png';
  return `data:${mime};base64,${buffer.toString('base64')}`;
}

async function getImageSize(filePath) {
  const buffer = await fs.readFile(filePath);
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.png') {
    return {
      width: buffer.readUInt32BE(16),
      height: buffer.readUInt32BE(20),
    };
  }
  if (ext === '.jpg' || ext === '.jpeg') {
    let offset = 2;
    while (offset < buffer.length) {
      if (buffer[offset] !== 0xff) {
        offset += 1;
        continue;
      }
      const marker = buffer[offset + 1];
      const length = buffer.readUInt16BE(offset + 2);
      if (marker >= 0xc0 && marker <= 0xc3) {
        return {
          height: buffer.readUInt16BE(offset + 5),
          width: buffer.readUInt16BE(offset + 7),
        };
      }
      offset += 2 + length;
    }
  }
  return { width: 1200, height: 1200 };
}

async function convertSvgToJpeg(svgPath, jpgPath) {
  const attempts = [
    ['sips', ['-s', 'format', 'jpeg', svgPath, '--out', jpgPath]],
    ['magick', [svgPath, '-background', 'white', '-alpha', 'remove', '-alpha', 'off', jpgPath]],
  ];
  const failures = [];
  for (const [command, args] of attempts) {
    try {
      await execFileAsync(command, args);
      return path.resolve(jpgPath);
    } catch (error) {
      failures.push(`${command}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  throw new Error(`无法把 SVG 转成 JPEG 页面：${failures.join(' | ')}`);
}

function createPage(pages) {
  const page = {
    fragments: [],
    cursorY: MARGIN_Y,
    index: pages.length + 1,
  };

  page.fragments.push(
    `<rect width="${PAGE_WIDTH}" height="${PAGE_HEIGHT}" fill="#ffffff" />`,
    `<rect x="${MARGIN_X}" y="38" width="${CONTENT_WIDTH}" height="2" fill="#ebe8ff" />`,
    `<text x="${MARGIN_X}" y="54" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="14" font-weight="700" fill="#6a6398">HYFCeph Report</text>`,
    `<text x="${PAGE_WIDTH - MARGIN_X}" y="54" text-anchor="end" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="12" fill="#8a86ab">第 ${pages.length + 1} 页</text>`,
  );

  pages.push(page);
  return page;
}

function ensurePage(pages, minHeight = 120) {
  const page = pages[pages.length - 1] || createPage(pages);
  if (page.cursorY + minHeight <= PAGE_HEIGHT - MARGIN_Y) {
    return page;
  }
  return createPage(pages);
}

function addSectionTitle(page, title, subtitle = '') {
  page.fragments.push(
    `<text x="${MARGIN_X}" y="${page.cursorY}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="26" font-weight="800" fill="#1b1847">${escapeXml(title)}</text>`,
  );
  page.cursorY += 18;
  if (subtitle) {
    const lines = wrapText(subtitle, 78);
    for (const line of lines) {
      page.cursorY += 24;
      page.fragments.push(
        `<text x="${MARGIN_X}" y="${page.cursorY}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="14" fill="#67648f">${escapeXml(line)}</text>`,
      );
    }
  }
  page.cursorY += 20;
}

function addParagraph(page, text, maxUnits = 82, fontSize = 15, lineHeight = 24, color = '#4f4a7e') {
  const lines = wrapText(text, maxUnits);
  for (const line of lines) {
    page.fragments.push(
      `<text x="${MARGIN_X}" y="${page.cursorY}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="${fontSize}" fill="${color}">${escapeXml(line)}</text>`,
    );
    page.cursorY += lineHeight;
  }
  page.cursorY += 8;
}

function addSummaryChips(page, items) {
  let x = MARGIN_X;
  let y = page.cursorY;
  const chipHeight = 82;
  const gap = 14;
  const chipWidth = (CONTENT_WIDTH - gap * 2) / 3;
  items.forEach((item, index) => {
    const col = index % 3;
    const row = Math.floor(index / 3);
    x = MARGIN_X + col * (chipWidth + gap);
    y = page.cursorY + row * (chipHeight + gap);
    page.fragments.push(
      `<rect x="${x}" y="${y}" width="${chipWidth}" height="${chipHeight}" rx="18" fill="#f7f5ff" stroke="#e4defa" stroke-width="1" />`,
      `<text x="${x + 18}" y="${y + 28}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="12" font-weight="700" fill="#726aa6">${escapeXml(item.label)}</text>`,
      `<text x="${x + 18}" y="${y + 58}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="24" font-weight="800" fill="#1b1847">${escapeXml(item.value)}</text>`,
    );
  });
  page.cursorY += Math.ceil(items.length / 3) * (chipHeight + gap) + 6;
}

function addMetricGrid(page, metrics) {
  const cardsPerRow = 3;
  const gap = 14;
  const cardWidth = (CONTENT_WIDTH - gap * (cardsPerRow - 1)) / cardsPerRow;
  const cardHeight = 102;
  metrics.forEach((metric, index) => {
    const row = Math.floor(index / cardsPerRow);
    const col = index % cardsPerRow;
    const x = MARGIN_X + col * (cardWidth + gap);
    const y = page.cursorY + row * (cardHeight + gap);
    page.fragments.push(
      `<rect x="${x}" y="${y}" width="${cardWidth}" height="${cardHeight}" rx="18" fill="#ffffff" stroke="#e4defa" stroke-width="1" />`,
      `<text x="${x + 18}" y="${y + 28}" font-family="Menlo, Consolas, monospace" font-size="13" font-weight="700" fill="#6c66a1">${escapeXml(metric.code || '-')}</text>`,
      `<text x="${x + 18}" y="${y + 61}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="28" font-weight="800" fill="${toneColor(metric.tone)}">${escapeXml(safeMetricValue(metric))}</text>`,
      `<text x="${x + 18}" y="${y + 84}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="#726d9a">${escapeXml(metric.label || metric.code || '')}</text>`,
    );
  });
  page.cursorY += Math.ceil(metrics.length / cardsPerRow) * (cardHeight + gap) + 4;
}

async function addImageBlock(page, imagePath, title) {
  if (!imagePath) {
    return;
  }
  const dataUri = await imageToDataUri(imagePath);
  if (!dataUri) {
    return;
  }
  const imageSize = await getImageSize(imagePath);
  const maxHeight = 620;
  const scale = Math.min(MAX_PAGE_IMAGE_WIDTH / imageSize.width, maxHeight / imageSize.height, 1);
  const width = round1(imageSize.width * scale);
  const height = round1(imageSize.height * scale);
  const x = MARGIN_X + (CONTENT_WIDTH - width) / 2;
  page.fragments.push(
    `<text x="${MARGIN_X}" y="${page.cursorY}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="18" font-weight="700" fill="#1b1847">${escapeXml(title)}</text>`,
  );
  page.cursorY += 18;
  page.fragments.push(
    `<rect x="${x - 10}" y="${page.cursorY}" width="${width + 20}" height="${height + 20}" rx="18" fill="#fbfaff" stroke="#e4defa" stroke-width="1" />`,
    `<image href="${dataUri}" x="${x}" y="${page.cursorY + 10}" width="${width}" height="${height}" preserveAspectRatio="xMidYMid meet" />`,
  );
  page.cursorY += height + 38;
}

function frameworkRowHeight() {
  return 30;
}

function drawTableHeader(page, columns) {
  const headerY = page.cursorY;
  page.fragments.push(
    `<rect x="${MARGIN_X}" y="${headerY}" width="${CONTENT_WIDTH}" height="34" rx="10" fill="#f4f2fe" />`,
  );
  columns.forEach((column) => {
    page.fragments.push(
      `<text x="${column.x}" y="${headerY + 22}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="12" font-weight="700" fill="#6b649d">${escapeXml(column.label)}</text>`,
    );
  });
  page.cursorY += 42;
}

function addSingleFrameworkRows(pages, framework) {
  const columns = [
    { label: '项目', x: MARGIN_X + 12, width: 260 },
    { label: '数值', x: MARGIN_X + 270, width: 160 },
    { label: '参考', x: MARGIN_X + 430, width: 250 },
    { label: '状态', x: MARGIN_X + 700, width: 120 },
  ];
  let page = ensurePage(pages, 120);
  addSectionTitle(page, framework.label, `完整项目 ${framework.items.length} 项，当前状态：${formatFrameworkStatus(framework.status)}`);
  drawTableHeader(page, columns);

  for (const item of ensureArray(framework.items)) {
    page = ensurePage(pages, 56);
    if (page.cursorY <= MARGIN_Y + 140) {
      drawTableHeader(page, columns);
    }
    const y = page.cursorY;
    const valueText = item.status === 'supported'
      ? (item.valueText || (Number.isFinite(item.value) ? String(item.value) : '-'))
      : `暂不支持：${item.reason || '-'}`;
    const statusText = item.status === 'supported'
      ? (item.tone === 'success' ? '在范围内' : item.tone === 'danger' ? '偏离较大' : item.tone === 'warn' ? '轻度偏离' : '已计算')
      : '未算出';
    page.fragments.push(
      `<line x1="${MARGIN_X}" y1="${y + 22}" x2="${MARGIN_X + CONTENT_WIDTH}" y2="${y + 22}" stroke="#ece8fd" stroke-width="1" />`,
      `<text x="${columns[0].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" font-weight="700" fill="#1b1847">${escapeXml(item.label || item.code || '-')}</text>`,
      `<text x="${columns[1].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="${item.status === 'supported' ? toneColor(item.tone) : '#8b6380'}">${escapeXml(valueText)}</text>`,
      `<text x="${columns[2].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="#635d93">${escapeXml(item.reference || '-')}</text>`,
      `<text x="${columns[3].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="#635d93">${escapeXml(statusText)}</text>`,
    );
    page.cursorY += frameworkRowHeight();
  }

  page.cursorY += SECTION_GAP;
}

function buildOverlapComparisonRows(baseFramework, compareFramework) {
  const baseItems = new Map(ensureArray(baseFramework?.items).map((item) => [item.code, item]));
  const compareItems = new Map(ensureArray(compareFramework?.items).map((item) => [item.code, item]));
  const codes = Array.from(new Set([...baseItems.keys(), ...compareItems.keys()]));
  return codes.map((code) => ({
    code,
    base: baseItems.get(code) || null,
    compare: compareItems.get(code) || null,
  }));
}

function addOverlapFrameworkRows(pages, label, baseFramework, compareFramework) {
  const rows = buildOverlapComparisonRows(baseFramework, compareFramework);
  const columns = [
    { label: '项目', x: MARGIN_X + 12 },
    { label: '治疗前', x: MARGIN_X + 222 },
    { label: '治疗后', x: MARGIN_X + 412 },
    { label: '参考', x: MARGIN_X + 602 },
    { label: '差值', x: MARGIN_X + 832 },
  ];

  let page = ensurePage(pages, 120);
  addSectionTitle(page, label, `治疗前 ${formatFrameworkStatus(baseFramework?.status)}，治疗后 ${formatFrameworkStatus(compareFramework?.status)}。`);
  drawTableHeader(page, columns);

  for (const row of rows) {
    page = ensurePage(pages, 56);
    if (page.cursorY <= MARGIN_Y + 140) {
      drawTableHeader(page, columns);
    }
    const y = page.cursorY;
    const baseValue = row.base?.status === 'supported' ? (row.base.valueText || '-') : `未算出`;
    const compareValue = row.compare?.status === 'supported' ? (row.compare.valueText || '-') : `未算出`;
    const reference = row.base?.reference || row.compare?.reference || '-';
    const delta = row.base?.status === 'supported' && row.compare?.status === 'supported' && Number.isFinite(row.base.value) && Number.isFinite(row.compare.value)
      ? `${round1(row.compare.value - row.base.value)}${row.base.unit === 'mm' ? ' mm' : row.base.unit === '%' ? '%' : '°'}`
      : '-';

    page.fragments.push(
      `<line x1="${MARGIN_X}" y1="${y + 22}" x2="${MARGIN_X + CONTENT_WIDTH}" y2="${y + 22}" stroke="#ece8fd" stroke-width="1" />`,
      `<text x="${columns[0].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" font-weight="700" fill="#1b1847">${escapeXml(row.base?.label || row.compare?.label || row.code || '-')}</text>`,
      `<text x="${columns[1].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="${row.base?.status === 'supported' ? toneColor(row.base?.tone) : '#8b6380'}">${escapeXml(baseValue)}</text>`,
      `<text x="${columns[2].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="${row.compare?.status === 'supported' ? toneColor(row.compare?.tone) : '#8b6380'}">${escapeXml(compareValue)}</text>`,
      `<text x="${columns[3].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="#635d93">${escapeXml(reference)}</text>`,
      `<text x="${columns[4].x}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="#635d93">${escapeXml(delta)}</text>`,
    );
    page.cursorY += frameworkRowHeight();
  }
  page.cursorY += SECTION_GAP;
}

function buildSingleSummaryItems(result) {
  const analysis = result.analysis || {};
  return [
    { label: '模式', value: '单图测量' },
    { label: '结论', value: analysis.riskLabel || '-' },
    { label: '支持指标', value: String(ensureArray(result.metrics).length) },
  ];
}

function buildOverlapSummaryItems(result) {
  return [
    { label: '模式', value: '重叠对比' },
    { label: '对齐', value: result.alignMode || result.summary?.alignLabel || '-' },
    { label: '框架', value: String(ensureArray(result.frameworkChoices).length) },
  ];
}

function makeSvgPage(page) {
  return [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${PAGE_WIDTH}" height="${PAGE_HEIGHT}" viewBox="0 0 ${PAGE_WIDTH} ${PAGE_HEIGHT}">`,
    ...page.fragments,
    `</svg>`,
  ].join('');
}

async function renderPagesToJpegs(svgPages, tempDir) {
  const pages = [];
  for (let index = 0; index < svgPages.length; index += 1) {
    const svgPath = path.join(tempDir, `page-${String(index + 1).padStart(2, '0')}.svg`);
    const jpgPath = path.join(tempDir, `page-${String(index + 1).padStart(2, '0')}.jpg`);
    await fs.writeFile(svgPath, svgPages[index], 'utf8');
    await convertSvgToJpeg(svgPath, jpgPath);
    const jpegBuffer = await fs.readFile(jpgPath);
    const { width, height } = await getImageSize(jpgPath);
    pages.push({
      jpegBuffer,
      imageWidth: width,
      imageHeight: height,
    });
  }
  return pages;
}

async function generateLegacyPdfReport({ inputPath, outputPath }) {
  const resolvedInputPath = path.resolve(inputPath);
  const resolvedOutputPath = path.resolve(outputPath || defaultPdfPath(resolvedInputPath));
  const payload = JSON.parse(await fs.readFile(resolvedInputPath, 'utf8'));
  const pages = [];
  let page = createPage(pages);

  const mode = String(payload.mode || payload.analysis?.type || 'image').trim();
  const reportTitle = mode === 'overlap' ? 'HYFCeph 重叠对比报告' : 'HYFCeph 侧位片测量报告';
  const generatedAt = formatDateTime(new Date().toISOString());
  addSectionTitle(page, reportTitle, `本地生成时间：${generatedAt}`);

  if (mode === 'overlap') {
    addSummaryChips(page, buildOverlapSummaryItems(payload));
    addParagraph(page, `治疗前结论：${payload.analysis?.base?.riskLabel || payload.summary?.baseRiskLabel || '-'}。治疗后结论：${payload.analysis?.compare?.riskLabel || payload.summary?.compareRiskLabel || '-'}。`, 78);
    await addImageBlock(page, payload.annotatedPngPath, '重叠图');

    const baseMetrics = ensureArray(payload.analysis?.base?.metrics);
    const compareMetrics = ensureArray(payload.analysis?.compare?.metrics);
    const baseMetricMap = new Map(baseMetrics.map((metric) => [metric.code, metric]));
    const compareMetricMap = new Map(compareMetrics.map((metric) => [metric.code, metric]));
    const metricRows = Array.from(new Set([...baseMetricMap.keys(), ...compareMetricMap.keys()])).map((code) => ({
      code,
      base: baseMetricMap.get(code) || null,
      compare: compareMetricMap.get(code) || null,
    }));

    page = ensurePage(pages, 160);
    addSectionTitle(page, '关键指标对比', '以下为服务端本次返回的治疗前后主要指标对比。');
    drawTableHeader(page, [
      { label: '指标', x: MARGIN_X + 12 },
      { label: '治疗前', x: MARGIN_X + 250 },
      { label: '治疗后', x: MARGIN_X + 470 },
      { label: '变化', x: MARGIN_X + 690 },
    ]);
    for (const row of metricRows) {
      page = ensurePage(pages, 56);
      if (page.cursorY <= MARGIN_Y + 140) {
        drawTableHeader(page, [
          { label: '指标', x: MARGIN_X + 12 },
          { label: '治疗前', x: MARGIN_X + 250 },
          { label: '治疗后', x: MARGIN_X + 470 },
          { label: '变化', x: MARGIN_X + 690 },
        ]);
      }
      const y = page.cursorY;
      const baseText = safeMetricValue(row.base);
      const compareText = safeMetricValue(row.compare);
      const delta = row.base && row.compare && Number.isFinite(row.base.value) && Number.isFinite(row.compare.value)
        ? `${round1(row.compare.value - row.base.value)}`
        : '-';
      page.fragments.push(
        `<line x1="${MARGIN_X}" y1="${y + 22}" x2="${MARGIN_X + CONTENT_WIDTH}" y2="${y + 22}" stroke="#ece8fd" stroke-width="1" />`,
        `<text x="${MARGIN_X + 12}" y="${y + 18}" font-family="Menlo, Consolas, monospace" font-size="13" font-weight="700" fill="#1b1847">${escapeXml(row.code)}</text>`,
        `<text x="${MARGIN_X + 250}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="${row.base ? toneColor(row.base.tone) : '#8b6380'}">${escapeXml(baseText)}</text>`,
        `<text x="${MARGIN_X + 470}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="${row.compare ? toneColor(row.compare.tone) : '#8b6380'}">${escapeXml(compareText)}</text>`,
        `<text x="${MARGIN_X + 690}" y="${y + 18}" font-family="PingFang SC, Noto Sans SC, sans-serif" font-size="13" fill="#635d93">${escapeXml(delta)}</text>`,
      );
      page.cursorY += frameworkRowHeight();
    }
    page.cursorY += SECTION_GAP;

    const baseFrameworks = normalizeFrameworkEntries(payload.analysis?.base?.frameworkReports, payload.frameworkChoices);
    const compareFrameworkMap = new Map(normalizeFrameworkEntries(payload.analysis?.compare?.frameworkReports, payload.frameworkChoices).map((item) => [item.code, item]));
    for (const framework of baseFrameworks) {
      addOverlapFrameworkRows(pages, framework.label, framework, compareFrameworkMap.get(framework.code));
    }
  } else {
    addSummaryChips(page, buildSingleSummaryItems(payload));
    addParagraph(page, payload.analysis?.insight || payload.summary?.riskLabel || '本次服务端测量已完成。', 80);
    await addImageBlock(page, payload.annotatedPngPath, '标注图');

    page = ensurePage(pages, 180);
    addSectionTitle(page, '关键指标', '以下为本次返回的主要测量值。');
    addMetricGrid(page, ensureArray(payload.metrics));

    const frameworks = normalizeFrameworkEntries(payload.analysis?.frameworkReports, payload.frameworkChoices);
    for (const framework of frameworks) {
      addSingleFrameworkRows(pages, framework);
    }
  }

  const svgPages = pages.map((item) => makeSvgPage(item));
  const tempDir = await fs.mkdtemp(path.join(process.cwd(), 'hyfceph-pdf-'));
  const rasterPages = await renderPagesToJpegs(svgPages, tempDir);
  const pdfBuffer = buildJpegPdf(rasterPages);
  await fs.mkdir(path.dirname(resolvedOutputPath), { recursive: true });
  await fs.writeFile(resolvedOutputPath, pdfBuffer);
  return path.resolve(resolvedOutputPath);
}

export async function generateHyfcephPdfReport({ inputPath, outputPath, patientName }) {
  const resolvedInputPath = path.resolve(inputPath);
  const resolvedOutputPath = path.resolve(outputPath || defaultPdfPath(resolvedInputPath));
  const payload = JSON.parse(await fs.readFile(resolvedInputPath, 'utf8'));
  if (patientName) {
    payload.patientName = patientName;
  }

  try {
    const html = await buildHtmlReport(payload);
    await fs.mkdir(path.dirname(resolvedOutputPath), { recursive: true });
    return await renderHtmlToPdfWithChrome(html, resolvedOutputPath);
  } catch (error) {
    return generateLegacyPdfReport({
      inputPath: resolvedInputPath,
      outputPath: resolvedOutputPath,
    });
  }
}

async function main() {
  const { values } = parseArgs({
    options: {
      input: { type: 'string' },
      output: { type: 'string' },
      help: { type: 'boolean', short: 'h', default: false },
    },
  });

  if (values.help || !values.input) {
    console.log(`Usage:
  node scripts/hyfceph-report-pdf.mjs --input /path/to/result.json [--output /path/to/report.pdf]
`);
    return;
  }

  const pdfPath = await generateHyfcephPdfReport({
    inputPath: values.input,
    outputPath: values.output,
  });

  console.log(JSON.stringify({ pdfPath }, null, 2));
}

const isDirectRun = (() => {
  if (!process.argv[1]) {
    return false;
  }
  return path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
})();

if (isDirectRun) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  });
}
