#!/usr/bin/env node

import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import process from 'node:process';
import { parseArgs } from 'node:util';
import { generateHyfcephPdfReport } from './hyfceph-report-pdf.mjs';

const DEFAULT_PORTAL_BASE_URL = 'https://hyfceph.52ortho.com/';
const LAST_RESULT_STATE_PATH = path.join(os.homedir(), '.codex/state/hyfceph-last-result.json');

function ensureTrailingSlash(value) {
  return value.endsWith('/') ? value : `${value}/`;
}

function timestampSlug() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function defaultBaseName(mode) {
  return `hyfceph-${mode}-${timestampSlug()}`;
}

function printHelp() {
  console.log(`Usage:
  node scripts/hyfceph-service-client.mjs --image /path/to/ceph.png [options]
  node scripts/hyfceph-service-client.mjs --image /path/to/base.png --compare-image /path/to/compare.png [options]
  node scripts/hyfceph-service-client.mjs --pdf-input /path/to/result.json [options]
  node scripts/hyfceph-service-client.mjs --latest-pdf [options]

Required:
  --api-key <key>                HYFCeph API Key (PDF-only mode not required)

Options:
  --portal-base-url <url>        HYFCeph portal URL, default: ${DEFAULT_PORTAL_BASE_URL}
  --image <file>                 Upload a local ceph image and measure it on the server
  --compare-image <file>         Upload a second ceph image and generate an overlap PNG
  --align-mode <SN|FH>           Overlap alignment mode, default: SN
  --output <file>                Output JSON path
  --annotated-png-output <file>  Output PNG path
  --annotated-svg-output <file>  Output SVG path
  --generate-pdf                 Generate a local PDF after the current measurement run
  --pdf-output <file>            Output PDF path
  --pdf-input <file>             Generate a PDF from an existing HYFCeph result JSON
  --latest-pdf                   Generate a PDF from the latest locally recorded HYFCeph result
`);
}

async function requestJson(url, {
  method = 'GET',
  headers = {},
  body,
} = {}) {
  const finalHeaders = { ...headers };
  let payload = body;
  if (body && typeof body !== 'string') {
    payload = JSON.stringify(body);
    finalHeaders['Content-Type'] ??= 'application/json';
  }

  const response = await fetch(url, {
    method,
    headers: finalHeaders,
    body: method === 'GET' || method === 'HEAD' ? undefined : payload,
  });

  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    throw new Error(`Expected JSON but got: ${text.slice(0, 500)}`);
  }

  if (!response.ok) {
    throw new Error(data?.error || `HTTP ${response.status} ${response.statusText}`);
  }

  return data;
}

async function writeText(filePath, content) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, content, 'utf8');
  return path.resolve(filePath);
}

async function writeJson(filePath, value) {
  return writeText(filePath, JSON.stringify(value, null, 2));
}

async function writeBase64(filePath, base64) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, Buffer.from(base64, 'base64'));
  return path.resolve(filePath);
}

async function readLastResultState() {
  try {
    const raw = await fs.readFile(LAST_RESULT_STATE_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

async function writeLastResultState(state) {
  await writeJson(LAST_RESULT_STATE_PATH, state);
  return LAST_RESULT_STATE_PATH;
}

function mimeTypeFromPath(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.png') return 'image/png';
  if (ext === '.jpg' || ext === '.jpeg') return 'image/jpeg';
  if (ext === '.webp') return 'image/webp';
  if (ext === '.bmp') return 'image/bmp';
  if (ext === '.tif' || ext === '.tiff') return 'image/tiff';
  return 'application/octet-stream';
}

async function main() {
  const { values, positionals } = parseArgs({
    options: {
      'api-key': { type: 'string' },
      'portal-base-url': { type: 'string', default: DEFAULT_PORTAL_BASE_URL },
      image: { type: 'string' },
      'compare-image': { type: 'string' },
      'align-mode': { type: 'string', default: 'SN' },
      output: { type: 'string' },
      'annotated-png-output': { type: 'string' },
      'annotated-svg-output': { type: 'string' },
      'generate-pdf': { type: 'boolean', default: false },
      'pdf-output': { type: 'string' },
      'pdf-input': { type: 'string' },
      'latest-pdf': { type: 'boolean', default: false },
      'share-url': { type: 'string' },
      'current-case': { type: 'boolean', default: false },
      help: { type: 'boolean', short: 'h', default: false },
    },
  });

  if (values.help) {
    printHelp();
    return;
  }

  const pdfInput = String(values['pdf-input'] || '').trim();
  const latestPdf = values['latest-pdf'];
  const pdfOutput = String(values['pdf-output'] || '').trim();

  if (pdfInput || latestPdf) {
    const inputPath = pdfInput
      ? path.resolve(pdfInput)
      : await (async () => {
          const state = await readLastResultState();
          const latestResultPath = String(state?.resultJsonPath || '').trim();
          if (!latestResultPath) {
            throw new Error('当前没有可用的最近一次测量结果，无法生成 PDF。请先完成一次测量。');
          }
          return path.resolve(latestResultPath);
        })();

    const pdfPath = await generateHyfcephPdfReport({
      inputPath,
      outputPath: pdfOutput || undefined,
    });

    const lastState = await readLastResultState();
    await writeLastResultState({
      ...(lastState || {}),
      resultJsonPath: inputPath,
      pdfReportPath: pdfPath,
      updatedAt: new Date().toISOString(),
    });

    console.log(JSON.stringify({
      inputPath,
      pdfPath,
    }, null, 2));
    return;
  }

  const apiKey = String(values['api-key'] || process.env.HYFCEPH_API_KEY || '').trim();
  if (!apiKey) {
    throw new Error('Missing HYFCeph API Key. Provide --api-key or HYFCEPH_API_KEY.');
  }

  const imagePath = String(values.image || positionals[0] || '').trim();
  const compareImagePath = String(values['compare-image'] || '').trim();
  const shareUrl = String(values['share-url'] || '').trim();
  const currentCase = values['current-case'] || (!shareUrl && !imagePath);
  const overlapMode = Boolean(imagePath && compareImagePath);
  const alignMode = String(values['align-mode'] || 'SN').trim().toUpperCase() || 'SN';

  const portalBaseUrl = ensureTrailingSlash(String(values['portal-base-url'] || process.env.HYFCEPH_PORTAL_BASE_URL || DEFAULT_PORTAL_BASE_URL).trim());
  const mode = overlapMode ? 'overlap' : (imagePath ? 'image' : (shareUrl ? 'share-url' : 'current-case'));
  const baseName = defaultBaseName(mode);
  const outputPath = path.resolve(values.output || path.join(process.cwd(), `${baseName}.json`));
  const annotatedPngPath = path.resolve(values['annotated-png-output'] || path.join(process.cwd(), `${baseName}.png`));
  const annotatedSvgPath = path.resolve(values['annotated-svg-output'] || path.join(process.cwd(), `${baseName}.svg`));

  const endpoint = new URL(
    overlapMode
      ? 'api/measure/overlap'
      : imagePath
      ? 'api/measure/image'
      : (shareUrl ? 'api/measure/share-url' : 'api/measure/current-case'),
    portalBaseUrl,
  ).toString();

  let payload;
  try {
    const requestBody = overlapMode
      ? await (async () => {
          const resolvedBaseImagePath = path.resolve(imagePath);
          const resolvedCompareImagePath = path.resolve(compareImagePath);
          const [baseImageBuffer, compareImageBuffer] = await Promise.all([
            fs.readFile(resolvedBaseImagePath),
            fs.readFile(resolvedCompareImagePath),
          ]);
          return {
            baseFileName: path.basename(resolvedBaseImagePath),
            baseMimeType: mimeTypeFromPath(resolvedBaseImagePath),
            baseImageBase64: baseImageBuffer.toString('base64'),
            compareFileName: path.basename(resolvedCompareImagePath),
            compareMimeType: mimeTypeFromPath(resolvedCompareImagePath),
            compareImageBase64: compareImageBuffer.toString('base64'),
            alignMode,
          };
        })()
      : imagePath
        ? await (async () => {
          const resolvedImagePath = path.resolve(imagePath);
          const imageBuffer = await fs.readFile(resolvedImagePath);
          return {
            fileName: path.basename(resolvedImagePath),
            mimeType: mimeTypeFromPath(resolvedImagePath),
            imageBase64: imageBuffer.toString('base64'),
          };
        })()
        : (shareUrl ? { shareUrl } : {});
    payload = await requestJson(endpoint, {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
      },
      body: requestBody,
    });
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    if (/服务端远程会话暂不可用/.test(reason)) {
      throw new Error('服务端远程会话暂不可用，请稍后再试。');
    }
    if (!imagePath && !shareUrl && /当前病例|同步|桥接/.test(reason)) {
      throw new Error('服务端当前没有可用病例。请改为直接发送侧位片。');
    }
    throw error;
  }

  const result = payload.result || {};
  const artifacts = result.artifacts || {};
  let resolvedPngPath = null;
  let resolvedSvgPath = null;

  if (artifacts.annotatedPngBase64) {
    resolvedPngPath = await writeBase64(annotatedPngPath, artifacts.annotatedPngBase64);
  }
  if (artifacts.annotatedSvgBase64) {
    resolvedSvgPath = await writeText(
      annotatedSvgPath,
      Buffer.from(artifacts.annotatedSvgBase64, 'base64').toString('utf8'),
    );
  }

  const output = {
    ok: payload.ok !== false,
    mode: payload.mode || mode,
    portalBaseUrl,
    alignMode: result.summary?.alignMode || (overlapMode ? alignMode : null),
    analysis: result.analysis || null,
    analysisError: result.analysisError || null,
    annotationError: result.annotationError || null,
    summary: result.summary || null,
    frameworkChoices: result.analysis?.frameworkChoices || result.summary?.frameworkChoices || [],
    metrics: result.metrics || [],
    taskId: result.taskId || null,
    resultUrl: result.resultUrl || null,
    annotatedPngPath: resolvedPngPath,
    annotatedSvgPath: resolvedSvgPath,
  };

  await writeJson(outputPath, output);

  let pdfReportPath = null;
  if (values['generate-pdf']) {
    pdfReportPath = await generateHyfcephPdfReport({
      inputPath: outputPath,
      outputPath: pdfOutput || undefined,
    });
    output.pdfReportPath = pdfReportPath;
    await writeJson(outputPath, output);
  }

  await writeLastResultState({
    resultJsonPath: outputPath,
    annotatedPngPath: resolvedPngPath,
    annotatedSvgPath: resolvedSvgPath,
    pdfReportPath,
    mode: output.mode,
    updatedAt: new Date().toISOString(),
  });

  console.log(JSON.stringify({
    outputPath,
    annotatedPngPath: resolvedPngPath,
    annotatedSvgPath: resolvedSvgPath,
    pdfReportPath,
    summary: output.summary,
    frameworkChoices: output.frameworkChoices,
    metrics: output.metrics,
    analysisError: output.analysisError,
    annotationError: output.annotationError,
  }, null, 2));
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
