---
name: hyfceph
description: Run the HYFCeph cephalometric workflow through the HYFCeph portal with an API key by uploading one or two local lateral ceph images. The public user only sends images; the server reuses the owner's synced browser session behind the scenes. Save a local result JSON, write an annotated PNG, and return supported cephalometric metrics or overlap traces. Use when the user wants HYFCeph analysis, mentions HYFCeph, provides an API key, or sends ceph images.
---

# HYFCeph

Use the bundled Node service client.

In user-facing replies, use `HYFCeph` or `Ceph`.

Do not include platform URLs, share URLs, token values, request headers, or raw JSON in the user-facing reply.

## Publishing model

Do not try to protect a public skill by encrypting `SKILL.md` or local scripts. That only creates client-side obfuscation. Anyone who can run the public skill can also recover its plaintext instructions or patch out local checks.

If you want public distribution plus commercial control, use this structure:

1. Publish only a thin client skill.
2. Keep proprietary prompts, orchestration logic, vendor credentials, quotas, and billing checks on your own server.
3. Let users register on your website and get an API key.
4. Make your server validate the API key and return only the result payload needed by the skill.

This is the only reliable way to hide real business logic.

## Registration gate

Before measurement starts, require an API key.

Use this reply when the user has not yet provided an API key:

`你好，我是 HYFCeph。请先前往 https://hyfceph.52ortho.com/ 注册账号并获取 API Key。拿到后把 API Key 发我，我再开始测量。`

Do not continue into measurement until the user has either:

- provided an API key in the conversation, or
- clearly said their key has already been configured in the environment.

## First reply rule

When the skill is triggered and the user has not yet给出 API key:

1. Send only the short registration guidance above.
2. Do not send old metrics, old case data, old images, or cached results.
3. Do not run the measurement flow yet.

## Default workflow

After the user has provided an API key and explicitly asked to start measurement:

1. If the user has provided one local ceph image, upload it to the portal and run:

```bash
HYFCEPH_API_KEY='user-api-key' \
node scripts/hyfceph-service-client.mjs --image /path/to/ceph.png
```

2. If the user has provided two local ceph images and wants overlap comparison, treat the first image as the base trace and the second as the comparison trace. Default to `SN` alignment unless the user explicitly asks for `FH`:

```bash
HYFCEPH_API_KEY='user-api-key' \
node scripts/hyfceph-service-client.mjs \
  --image /path/to/base-ceph.png \
  --compare-image /path/to/compare-ceph.png \
  --align-mode SN
```

This is the default public path. The user does not install any plugin, does not provide a share link, and does not handle upstream tokens.

3. Read the service-client result JSON from disk, but do not paste it back to the user.

4. Prefer the generated PNG artifact in the reply:
   - `annotatedPngPath`
   - If PNG conversion is unavailable on that device, fall back to `annotatedSvgPath`.

5. Use `analysis`, `metrics`, `summary`, `analysisError`, and `annotationError` for the human-readable interpretation.

6. After a completed run, if the user asks to generate a PDF, do not rerun the measurement unless the input images changed. Prefer the latest local result and run:

```bash
node scripts/hyfceph-service-client.mjs --latest-pdf
```

If you already know the exact result JSON path, you may use:

```bash
node scripts/hyfceph-service-client.mjs --pdf-input /absolute/path/to/result.json
```

The PDF is generated locally on this machine first, then returned to the user as a local file link. If the user later asks for additional analysis frameworks, or the case is a treatment-before/after overlap comparison, the PDF should include those framework tables and overlap comparison pages as well.

## Outputs

The service client saves a local result JSON plus annotation files, but those files are for local persistence and debugging.

Prefer these reply-facing artifacts:

- `annotatedPngPath`: PNG landmark overlay or PNG overlap trace for direct display to the user
- `metrics`: supported measurements
- `analysis.riskLabel`: short classification summary
- `analysis.insight`: concise interpretation
- `summary`: point-count and supported-metric summary
- `portalBaseUrl`: the portal used for API key validation

## Reply style

When the run succeeds:

1. Give a short clinical summary in plain Chinese.
2. Show the annotated PNG directly with Markdown image syntax using the absolute local path.
3. For single-image measurement, list the supported metric values in concise prose or a short flat list.
4. For overlap mode, mention the alignment mode and summarize the base/compare conclusions. Do not dump both raw metric arrays unless the user asks.
5. Do not mention JSON files unless the user explicitly asks for raw data.
6. End by asking which analysis framework they want next, and remind them that a PDF can also be generated locally and sent back.
7. Keep the existing data-and-analysis reply shape unchanged. The PDF is an additional optional artifact, not a replacement for the normal measurement reply.

Use this exact style for the closing choice line:

`可继续按以下分析法整理：Downs、Steiner、北大分析法、ABO、Ricketts、Tweed、McNamara、Jarabak。你选一个，我按那个口径继续解读。`

Add this exact follow-up line after it:

`如果你要，我也可以把这次结果整理成 PDF 发你；后续追加的分析法，或治疗前后重叠对比，也会一起收进 PDF。`

## Constraints

- Require Node.js 18 or newer because the script uses native `fetch`, `Blob`, and `FormData`.
- PNG conversion tries `sips`, then `magick`, then `rsvg-convert`. If none exist, use the SVG output instead.
- The public package should prefer `--image` whenever the user provides a ceph image.
- If the user provides two images, prefer overlap mode automatically and default to `SN` alignment.
- Do not expose current-case, plugin, token, share-link, or upstream-login workflows in user-facing replies unless the user explicitly asks for troubleshooting.
- If the server says the remote session is temporarily unavailable, tell the user to retry later. Do not expose internal bridge details.
- Do not expose credentials in the final response.
